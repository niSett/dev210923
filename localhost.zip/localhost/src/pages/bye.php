<?php

$response->setContent('Goodbye!');

?>